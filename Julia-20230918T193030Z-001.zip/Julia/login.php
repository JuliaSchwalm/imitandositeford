<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <title>0</title>
    <link rel = "stylesheet" href = "style2.css">
</head>

<body>
    
    <fieldset>
    <form action = "valida.php" method = "post">
        <legend>Login:</legend>
        <label>Usuário:<br><input type="nome" name="usuario" required maxlength="20" /></label><br>
        <label>Senha:<br><input type="password" name="senha" required maxlength="20" /></label><br><br>
        <button>Enviar</button><br>  
        </form>
        <form action = "../julia/insereUser.php" method = "post">
        <button>Cadastrar Usuário</button><br>  
    </form>
    </fieldset>



</body>
</html>