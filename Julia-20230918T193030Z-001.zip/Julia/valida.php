<?php
require_once 'conexao.php';

    session_start();
    //usuario passado por parametro no login.html
    $_SESSION['user'] = $_POST["usuario"];
    $_SESSION['password'] = $_POST["senha"];
    //consulta o banco de dados usuario
    $query = $conexao->query("SELECT * FROM user");

    while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
//se o usuario digita no cadastro estiver no banco vai para a pagina
    if ($_SESSION['user'] == $row['usuario'] && $_SESSION['password'] == $row['senha']){
       header("Location: index.html");
    } else {
        echo'<script>alert ("usuário não cadastrado") </script>';
        $url = "login.php";
        header("refresh:0; url= {$url}");
    }

    }
  
?>