<?php
    $servidor = 'localhost';
    $usuario = 'root';
    $senha = '';
    $banco = 'user';

    try{
        $conexao = new PDO('mysql:host=localhost; dbname=user', $usuario, $senha);   
        $conexao ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
    }
    catch(PDOException $e){
        echo 'ERRO: ' . $e->getMessage();
    }

?>